// КНОПКИ НАВИГАЦИИ
const btnScrollProduct = document.getElementById('scroll-product');
const btnScrollAbout = document.getElementById('scroll-about');
const btnScrollContact = document.getElementById('scroll-contact');

// КНОПКИ РЕГИСТРАЦИИ И ВХОДА
const loginModal = document.querySelector('.modal-window');
const openLoginBtn = document.querySelector('.login-btn');

const registrationModal = document.querySelector('.modal-window-reg');
const registrationModalBtn = document.querySelector('#register-btn');

const transToRegistration = document.querySelector('#transition-to-registration');
const transToLogin = document.querySelector('#transition-to-login');

// ЗАКРЫВАЧКИ
const closeLogin = document.querySelector('#closeLogin');
const closeRegistration = document.querySelector('#closeRegistration');

btnScrollProduct.addEventListener("click", function () {
    document.getElementById("why-div").scrollIntoView({ behavior: "smooth" });
});

btnScrollAbout.addEventListener("click", function () {
    document.getElementById("about-div").scrollIntoView({ behavior: "smooth" });
});

btnScrollContact.addEventListener("click", function () {
    document.getElementById("feedback-div").scrollIntoView({ behavior: "smooth" });
});

openLoginBtn.addEventListener('click', () => {
    loginModal.style.display = 'flex';
});

closeLogin.addEventListener('click', () => {
    loginModal.style.display = 'none';
});

registrationModalBtn.addEventListener('click', () => {
    registrationModal.style.display = 'flex';
});

closeRegistration.addEventListener('click', () => {
    registrationModal.style.display = 'none';
});

transToRegistration.addEventListener('click', () => {
    loginModal.style.display = 'none';
    registrationModal.style.display = 'flex';
});

transToLogin.addEventListener('click', () => {
    registrationModal.style.display = 'none';
    loginModal.style.display = 'flex';
});

// ЭЛЕМЕНТЫ КАЛЬКУЛЯТОРА
const totalLeadsNumberInput = document.getElementById('total-leads-number');
const revenueInput = document.getElementById('revenue');
const calculateButton = document.getElementById('btn');
const resultSpan = document.getElementById('result');

const matchingSpan = document.getElementById('matching');

calculateButton.addEventListener('click', () => {

    const totalNumber = parseInt(totalLeadsNumberInput.value) || 0;
    const revenue = parseInt(revenueInput.value) || 0;

    const result = revenue / totalNumber;

    if (result % 1 === 0) {
        resultSpan.textContent = result;
    } else {
        resultSpan.textContent = result.toFixed(2);
    }

    const matchingResult = result * 0.123;

    matchingSpan.textContent = matchingResult;
});

// ВХОД И РЕГИСТРАЦИЯ
const loginButton = document.getElementById('login-btn');
const registerButton = document.querySelector('#register-btn.login-btn');

loginButton.addEventListener('click', () => {
    window.location.href = "C:/Users/User/Desktop/Универ/3 курс/6 сем/ЭБ/Лаб3/html/home.html";
});

registerButton.addEventListener('click', () => {
    registrationModal.style.display = 'none';
    loginModal.style.display = 'flex';
})

const tryButton = document.querySelector('.mi-btn');

tryButton.addEventListener('click', () => {
    loginModal.style.display = 'none';
    registrationModal.style.display = 'flex';
});

// КНОПКИ НА КАРТОЧКАХ
const aboutCards = document.querySelectorAll('.about-card');
const imgCards = document.querySelectorAll('.img-card > img');
const logoCards = document.querySelectorAll('.logo-card');
const activeButtonCards = document.querySelectorAll('.active-button');

aboutCards.forEach((aboutCard, index) => {
    const imgCard = imgCards[index];
    const logoCard = logoCards[index];
    const activeButtonCard = activeButtonCards[index];

    aboutCard.addEventListener('mouseenter', () => {
        logoCard.src = "./resourse/logoHover.png";
        imgCard.src = "./resourse/moveOn2.png";
    });

    aboutCard.addEventListener('mouseleave', () => {
        logoCard.src = "./resourse/card-logo.png";
        imgCard.src = "./resourse/moveOn.png";
    });

    imgCard.addEventListener('click', () => {
        imgCard.style.display = 'none';
        activeButtonCard.style.display = 'flex';

        activeButtonCard.addEventListener('mouseenter', () => {
            activeButtonCard.style.scale = '1.2';
            activeButtonCard.style.transition = '0.3s';
        });

        activeButtonCard.addEventListener('mouseleave', () => {
            activeButtonCard.style.scale = '1';
            activeButtonCard.style.transition = '0.3s';
            activeButtonCard.style.boxShadow = 'none';
        });

    });
});

